from airflow import DAG
from airflow.operators.python import PythonOperator
from datetime import datetime
from pymongo import MongoClient

def insert_into_mongo(nk_id, origin, destination):
    client = MongoClient("mongodb://mongo:27017/")
    db = client["teste_db"]
    collection = db["teste_colecao"]
    
    documento = {
        "mensagem": "Airflow conectou no MongoDB com sucesso!",
        "nk_ota_localizer_id": nk_id,
        "place_origin_departure": origin,
        "place_destination_departure": destination
    }
    
    collection.insert_one(documento)
    client.close()

default_args = {
    "owner": "aluno",
    "start_date": datetime(2024, 1, 1),
    "retries": 1,
}

with DAG(
    dag_id="mongo_test_dag_encadeado",
    default_args=default_args,
    schedule_interval="@once",
    catchup=False,
) as dag:

    # Tarefa 1
    tarefa1 = PythonOperator(
        task_id="inserir_passagem_1",
        python_callable=insert_into_mongo,
        op_kwargs={
            "nk_id": 256789,
            "origin": "rio de janeiro",
            "destination": "são paulo"
        }
    )

    # Tarefa 2
    tarefa2 = PythonOperator(
        task_id="inserir_passagem_2",
        python_callable=insert_into_mongo,
        op_kwargs={
            "nk_id": 987654,
            "origin": "belo horizonte",
            "destination": "curitiba"
        }
    )

    # Tarefa 3
    tarefa3 = PythonOperator(
        task_id="inserir_passagem_3",
        python_callable=insert_into_mongo,
        op_kwargs={
            "nk_id": 123456,
            "origin": "porto alegre",
            "destination": "fortaleza"
        }
    )

    # Encadeamento: tarefa1 -> tarefa2 -> tarefa3
    tarefa1 >> tarefa2 >> tarefa3
